package com.networksecurity.modal;

/*******
 * <p>
 * Title:ClientLoginRowMapper
 * </p>
 * 
 * @author Garima Gautam
 * 
 * @version 1.00 2020-11-06
 * 
 */
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class clientloginRowMapper implements RowMapper<clientlogin>{

	@Override
	public clientlogin mapRow(ResultSet rs, int rowNum) throws SQLException {
		clientlogin client = new clientlogin();
		client.setClientId(rs.getInt("client_id"));
		client.setUsername(rs.getString("Username"));
		client.setEmailID(rs.getString("EmailID"));
		client.setPassword(rs.getString("Password"));
		return client;
	}

}
