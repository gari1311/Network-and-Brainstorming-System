package com.networksecurity.modal;

/*******
 * <p>
 * Title:ClientActivityRowMapper
 * </p>
 * 
 * @author Garima Gautam
 * 
 * @version 1.00 2020-11-06
 * 
 */
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class clientactivityRowMapper implements RowMapper<clientactivity>{

	@Override
	public clientactivity mapRow(ResultSet rs, int rowNum) throws SQLException {
		clientactivity client = new clientactivity();
		client.setActivityId(rs.getInt("activity_id"));
		client.setTitle(rs.getString("Title"));
		client.setDescription(rs.getString("Description"));
		return client;
	}

}
