package com.networksecurity.Service;

/*******
 * <p>
 * Title:ClientServiceImpl
 * </p>
 * 
 * @author Garima Gautam
 * 
 * @version 1.00 2020-11-06
 * 
 */
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.networksecurity.dao.ClientDAOImpl;
import com.networksecurity.modal.clientlogin;
@Service
public class ClientServiceImpl implements ClientService{
	@Autowired
	private ClientDAOImpl clientDao;

	@Override
	public List<clientlogin> getAllClients() {
		return clientDao.getAllClients();
	}

	@Override
	public clientlogin findClientById(int id) {
		return clientDao.findClientById(id);
	}

	@Override
	public void addClient(clientlogin client) {
		clientDao.addClient(client);
	}

	@Override
	public void updateClient(clientlogin client) {
		clientDao.updateClient(client);
	}

	@Override
	public void deleteClient(int id) {
		clientDao.deleteClient(id);
	}

}
