package com.networksecurity.Service;

/*******
 * <p>
 * Title:ClientActivityServiceImpl
 * </p>
 * 
 * @author Garima Gautam
 * 
 * @version 1.00 2020-11-06
 * 
 */
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.networksecurity.dao.ClientActivityDAOImpl;
import com.networksecurity.dao.ClientDAOImpl;
import com.networksecurity.modal.clientactivity;
import com.networksecurity.modal.clientlogin;
@Service
public class ClientActivityServiceImpl implements ClientActivityService{
	@Autowired
	private ClientActivityDAOImpl clientactivityDao;

	@Override
	public List<clientactivity> getAllActivities() {
		return clientactivityDao.getAllActivities();
	}

	@Override
	public clientactivity findActivityById(int id) {
		return clientactivityDao.findActivityById(id);
	}

	@Override
	public void addActivity(clientactivity client) {
		clientactivityDao.addActivity(client);
	}

	@Override
	public void updateActivity(clientactivity client) {
		clientactivityDao.updateActivity(client);
	}

	@Override
	public void deleteActivity(int id) {
		clientactivityDao.deleteActivity(id);
	}
	
	
}
