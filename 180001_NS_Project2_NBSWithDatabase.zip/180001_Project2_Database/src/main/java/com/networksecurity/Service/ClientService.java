package com.networksecurity.Service;

/*******
 * <p>
 * Title:ClientService
 * </p>
 * 
 * @author Garima Gautam
 * 
 * @version 1.00 2020-11-06
 * 
 */
import java.util.List;

import com.networksecurity.modal.clientlogin;

public interface ClientService {
	
	public List<clientlogin> getAllClients();
	
	public clientlogin findClientById(int id);
	
	public void addClient(clientlogin client);
	
	public void updateClient(clientlogin client);
	
	public void deleteClient(int id);

}
