package com.networksecurity.Service;

/*******
 * <p>
 * Title:SignService
 * </p>
 * 
 * @author Garima Gautam
 * 
 * @version 1.00 2020-11-06
 * 
 */
import org.springframework.stereotype.Service;

@Service
public class SigninService {
	
    public boolean validateAdmin(String userid, String password) {
        // mmdu, 12345
        return userid.equalsIgnoreCase("admin")
                && password.equalsIgnoreCase("11111");
    }
    
    public boolean validateClient(String userid, String password) {
        // mmdu, 12345
        return userid.equalsIgnoreCase("client")
                && password.equalsIgnoreCase("22222");
    }

}


