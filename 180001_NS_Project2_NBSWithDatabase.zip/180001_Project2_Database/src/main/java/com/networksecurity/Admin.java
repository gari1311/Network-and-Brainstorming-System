package com.networksecurity;

/*******
 * <p>
 * Title: Admin
 * </p>
 * 
 * @author Garima Gautam
 * 
 * @version 1.00 2020-11-06
 * 
 */

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

public class Admin {
	
public static void main (String args[]) throws Exception{
		
		try {
			ServerSocket ss = new ServerSocket(1001);
			System.out.println("Server is waiting for the client.....");
			Socket socket = ss.accept();
			System.out.println("Connection has been established.....");
			InputStreamReader isr = new InputStreamReader(socket.getInputStream());
			BufferedReader br = new BufferedReader(isr);
			String s = br.readLine();
			System.out.println("Message from Client : "+s);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

public String getOutput() {
	try {
		ServerSocket ss = new ServerSocket(1001);
		System.out.println("Server is waiting for the client.....");
		Socket socket = ss.accept();
		System.out.println("Connection has been established.....");
		InputStreamReader isr = new InputStreamReader(socket.getInputStream());
		BufferedReader br = new BufferedReader(isr);
		String s = br.readLine();
		String t = "Message from Client : "+s;
		System.out.println("Message from Client : "+s);
		return t;
	} catch (Exception e) {
		e.printStackTrace();
	}
	return "Client Not Connected";
}

}
