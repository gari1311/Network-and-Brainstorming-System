package com.networksecurity;

/*******
 * <p>
 * Title: Client
 * </p>
 * 
 * @author Garima Gautam
 * 
 * @version 1.00 2020-11-06
 * 
 */
import java.io.PrintWriter;
import java.net.Socket;

public class Client {

	public static void main (String args[]) throws Exception{
		
		try {
			Socket socket = new Socket("localhost", 1001);
			PrintWriter pw = new PrintWriter(socket.getOutputStream(), true);
			pw.println("Got Connected");
			pw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public String getOutput() {
		try {
			Socket socket = new Socket("localhost", 1001);
			PrintWriter pw = new PrintWriter(socket.getOutputStream(), true);
			pw.println("Got Connected");
			pw.close();
			return "Got Connected";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "Not Connected";
	}
}
