package com.networksecurity.controller;
/*******
 * <p>
 * Title: ClientActivityController
 * </p>
 * 
 * @author Garima Gautam
 * 
 * @version 1.00 2020-11-06
 * 
 */
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.networksecurity.Service.ClientActivityServiceImpl;
import com.networksecurity.Service.ClientServiceImpl;
import com.networksecurity.modal.clientactivity;
import com.networksecurity.modal.clientactivity;

@Controller
@RequestMapping("/clientactivity")
public class clientactivitycontroller {
	
	@Autowired
	private ClientActivityServiceImpl clientservice;
	
	@RequestMapping(value = {"/", "/list"}, method=RequestMethod.GET)
	public ModelAndView getAllActivities() {
		ModelAndView model = new ModelAndView();
		List<clientactivity> list = clientservice.getAllActivities();
		model.addObject("activity_list", list);
		model.setViewName("activity_list");
		return model;
	}
	
	@RequestMapping(value="/update/{id}", method=RequestMethod.GET)
	public ModelAndView editActivity(@PathVariable int id) {
		ModelAndView model = new ModelAndView();
		
		clientactivity client = clientservice.findActivityById(id);
		model.addObject("activityForm", client);
		model.setViewName("activity_Form");
		return model;
	}
	
	@RequestMapping(value="/add", method=RequestMethod.GET)
	public ModelAndView addActivity() {
		ModelAndView model = new ModelAndView();
		clientactivity client = new clientactivity();
		model.addObject("activityForm", client);
		model.setViewName("activity_Form");
		return model;
	}
	
	@RequestMapping(value="/save", method = RequestMethod.POST)
	public ModelAndView saveOrUpdate(@ModelAttribute("activityForm") clientactivity client) {
		if(client.getActivityId() != null) {
			clientservice.updateActivity(client);
		} else {
			clientservice.addActivity(client);
		}
		
		return new ModelAndView("redirect:/clientactivity/list");
	}
	
	
	/* @RequestMapping("manageclients")
		public String clientdashboard() {
			return "manageclients.jsp";
		}*/
	@RequestMapping(value="/delete/{id}", method = RequestMethod.GET)
	public ModelAndView deleteActivity(@PathVariable("id") int id) {
		clientservice.deleteActivity(id);
		
		return new ModelAndView("redirect:/clientactivity/list");
	}

}
