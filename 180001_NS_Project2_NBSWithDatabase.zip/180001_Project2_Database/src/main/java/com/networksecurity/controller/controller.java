package com.networksecurity.controller;

/*******
 * <p>
 * Title: Controller
 * </p>
 * 
 * @author Garima Gautam
 * 
 * @version 1.00 2020-11-06
 * 
 */

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.networksecurity.Service.SigninService;

@Controller
@SessionAttributes("name")
public class controller {
	
	@Autowired
    SigninService service;
	
	 @RequestMapping(value="/signin", method = RequestMethod.GET)
	    public String showLoginPage(ModelMap model){
	        return "/signin";
	    }

	 @RequestMapping(value="/signin", method = RequestMethod.POST)
	    public String showWelcomePage(ModelMap model, @RequestParam String name, @RequestParam String password){

	        boolean isValidAdmin = service.validateAdmin(name, password);
	        boolean isValidClient = service.validateClient(name, password);

	        if (!isValidAdmin || !isValidClient) {
	            model.put("errorMessage", "Invalid Credentials");
	            
	        }
	        if(isValidAdmin) {
	        model.put("name", name);
	        model.put("password", password);

	        return "/admindashboard";
	        }else if(isValidClient) {
	        	model.put("name", name);
	            model.put("password", password);

	            return "/clientdashboard";
	        }
	        return "/signin";
	    }
	/*
	@RequestMapping("signup")
	public String signup() {
		return "signup.jsp";
	}
	
	@RequestMapping("signin")
	public String signin() {
		return "signin.jsp";
	}
	
	@RequestMapping("clientdashboard")
	public String clientdashboard() {
		return "clientdashboard.jsp";
	}
	*/
	 
	
}
