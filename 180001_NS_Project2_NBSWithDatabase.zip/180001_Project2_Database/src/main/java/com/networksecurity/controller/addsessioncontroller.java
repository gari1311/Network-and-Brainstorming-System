package com.networksecurity.controller;
/*******
 * <p>
 * Title:Add Session
 * </p>
 * 
 * @author Garima Gautam
 * 
 * @version 1.00 2020-11-06
 * 
 */
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

@Controller
@SessionAttributes("name")
public class addsessioncontroller {
	
	 @RequestMapping("/addsession")
		public String clientdashboard() {
			return "/addsession";
		}

}
