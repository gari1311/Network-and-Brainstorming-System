package com.networksecurity.controller;

/*******
 * <p>
 * Title: ManageClientsController
 * </p>
 * 
 * @author Garima Gautam
 * 
 * @version 1.00 2020-11-06
 * 
 */

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.networksecurity.Service.ClientServiceImpl;
import com.networksecurity.modal.clientlogin;

@Controller
@RequestMapping("/manageclients")
public class manageclientscontroller {

	@Autowired
	private ClientServiceImpl clientservice;
	
	@RequestMapping(value = {"/", "/list"}, method=RequestMethod.GET)
	public ModelAndView getAllClients() {
		ModelAndView model = new ModelAndView();
		List<clientlogin> list = clientservice.getAllClients();
		model.addObject("client_list", list);
		model.setViewName("client_list");
		return model;
	}
	
	@RequestMapping(value="/update/{id}", method=RequestMethod.GET)
	public ModelAndView editClient(@PathVariable int id) {
		ModelAndView model = new ModelAndView();
		
		clientlogin client = clientservice.findClientById(id);
		model.addObject("clientForm", client);
		model.setViewName("client_Form");
		return model;
	}
	
	@RequestMapping(value="/add", method=RequestMethod.GET)
	public ModelAndView addClient() {
		ModelAndView model = new ModelAndView();
		clientlogin client = new clientlogin();
		model.addObject("clientForm", client);
		model.setViewName("client_Form");
		return model;
	}
	
	@RequestMapping(value="/save", method = RequestMethod.POST)
	public ModelAndView saveOrUpdate(@ModelAttribute("clientForm") clientlogin client) {
		if(client.getClientId() != null) {
			clientservice.updateClient(client);
		} else {
			clientservice.addClient(client);
		}
		
		return new ModelAndView("redirect:/manageclients/list");
	}
	
	
	/* @RequestMapping("manageclients")
		public String clientdashboard() {
			return "manageclients.jsp";
		}*/
	@RequestMapping(value="/delete/{id}", method = RequestMethod.GET)
	public ModelAndView deleteClient(@PathVariable("id") int id) {
		clientservice.deleteClient(id);
		
		return new ModelAndView("redirect:/manageclients/list");
	}
}
