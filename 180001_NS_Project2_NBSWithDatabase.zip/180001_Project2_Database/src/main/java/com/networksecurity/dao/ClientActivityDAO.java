package com.networksecurity.dao;

/*******
 * <p>
 * Title:ClientActivityDAO
 * </p>
 * 
 * @author Garima Gautam
 * 
 * @version 1.00 2020-11-06
 * 
 */

import java.util.List;

import com.networksecurity.modal.clientactivity;

public interface ClientActivityDAO {
	
public List<clientactivity> getAllActivities();
	
	public clientactivity findActivityById(int id);
	
	public void addActivity(clientactivity client);
	
	public void updateActivity(clientactivity client);
	
	public void deleteActivity(int id);

}
