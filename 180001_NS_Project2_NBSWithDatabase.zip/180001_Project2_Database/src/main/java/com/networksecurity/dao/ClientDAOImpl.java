package com.networksecurity.dao;

/*******
 * <p>
 * Title:ClientDAOImpl
 * </p>
 * 
 * @author Garima Gautam
 * 
 * @version 1.00 2020-11-06
 * 
 */
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.networksecurity.modal.clientlogin;
import com.networksecurity.modal.clientloginRowMapper;

@Transactional
@Repository
public class ClientDAOImpl implements ClientDAO{
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<clientlogin> getAllClients() {
		String query = "SELECT * from clientdetails";
		RowMapper<clientlogin> rowMapper = new clientloginRowMapper();
		List<clientlogin> list = jdbcTemplate.query(query, rowMapper);
		return list;
	}

	@Override
	public clientlogin findClientById(int id) {
		String query = "SELECT * FROM clientdetails WHERE client_id = ?";
		RowMapper<clientlogin> rowMapper = new BeanPropertyRowMapper<clientlogin>(clientlogin.class);
		clientlogin client = jdbcTemplate.queryForObject(query, rowMapper, id);
		return client;
	}

	@Override
	public void addClient(clientlogin client) {
		String query = "INSERT INTO clientdetails(client_id, Username, EmailID, Password) VALUES(?,?,?,?)";
		jdbcTemplate.update(query, client.getClientId(), client.getUsername(), client.getEmailID(), client.getPassword());
	}
	
	@Override
	public void updateClient(clientlogin client) {
		String query = "UPDATE clientdetails SET Username = ?,EmailID = ?, Password = ? WHERE client_id = ?";
		jdbcTemplate.update(query,  client.getUsername(), client.getEmailID(), client.getPassword(), client.getClientId());
	}

	@Override
	public void deleteClient(int id) {
		String query = "DELETE FROM clientdetails WHERE client_id = ?";
		jdbcTemplate.update(query, id);
		
	}

	
}
