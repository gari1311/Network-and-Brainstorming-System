package com.networksecurity.dao;

/*******
 * <p>
 * Title:ClientActivityDAOImpl
 * </p>
 * 
 * @author Garima Gautam
 * 
 * @version 1.00 2020-11-06
 * 
 */
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.networksecurity.modal.clientactivity;
import com.networksecurity.modal.clientactivityRowMapper;
import com.networksecurity.modal.clientlogin;
import com.networksecurity.modal.clientloginRowMapper;

@Transactional
@Repository
public class ClientActivityDAOImpl implements ClientActivityDAO{
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<clientactivity> getAllActivities() {
		String query = "SELECT * from clientactivity";
		RowMapper<clientactivity> rowMapper = new clientactivityRowMapper();
		List<clientactivity> list = jdbcTemplate.query(query, rowMapper);
		return list;
	}

	@Override
	public clientactivity findActivityById(int id) {
		String query = "SELECT * FROM clientactivity WHERE activity_id = ?";
		RowMapper<clientactivity> rowMapper = new BeanPropertyRowMapper<clientactivity>(clientactivity.class);
		clientactivity client = jdbcTemplate.queryForObject(query, rowMapper, id);
		return client;
	}

	@Override
	public void addActivity(clientactivity client) {
		String query = "INSERT INTO clientactivity(activity_id, Title, Description) VALUES(?,?,?)";
		jdbcTemplate.update(query, client.getActivityId(), client.getTitle(), client.getDescription());
	}
	
	@Override
	public void updateActivity(clientactivity client) {
		String query = "UPDATE clientactivity SET Title = ?, Description = ? WHERE activity_id = ?";
		jdbcTemplate.update(query,  client.getTitle(), client.getDescription(), client.getActivityId());
	}

	@Override
	public void deleteActivity(int id) {
		String query = "DELETE FROM clientactivity WHERE activity_id = ?";
		jdbcTemplate.update(query, id);
		
	}

	
}
